Smallworld is a Social Network system for XOOPS.

Inspired by the Srinivas Tamada tutorials on Facebook scripting.
The base system has been re-written, adapted, and heavily expanded for XOOPS by Culex The module is featuring
like/dislike, bookmarking, wall system, image gallery, and is using XIM if installed. The admin side is featuring
deleting users, banning users based on time. A countdown is shown on user side to when it's back. And many more features.
It is fully supported by XOOPS version 2.5.0 and higher.

Smallworld is released under the terms of the GNU General Public License (GPL) and is free to use and modify.
It is free to redistribute as long as you abide by the distribution terms of the GPL.